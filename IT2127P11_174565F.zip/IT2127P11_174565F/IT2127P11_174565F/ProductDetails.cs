﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT2127P11_174565F
{
    public partial class ProductDetails : Form
    {
        public ProductDetails()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void productsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.nYPStoreDataSet);

        }

        private void ProductDetails_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'nYPStoreDataSet.Products' table. You can move, or remove it, as needed.
            this.productsTableAdapter.Fill(this.nYPStoreDataSet.Products);

        }
    }
}
