﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT2127P11_174565F
{
    public partial class SurveyForm : Form
    {
        static string[] prodList = new string[5];
        public static string[] ProdList { get { return prodList; } }
        static int[] ratingList = new int[5];
        public static int[] RatingList { get { return ratingList; } }
        int prodCount = 0;
        public SurveyForm()
        {
            InitializeComponent();
        }

        private void SurveyForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'nYPStoreDataSet.Products' table. You can move, or remove it, as needed.
            this.productsTableAdapter.Fill(this.nYPStoreDataSet.Products);

        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            string prodName = "";
            int prodRating = 0;

            try
            {
                prodRating = int.Parse(textBoxRating.Text);
            }
            catch
            {
                MessageBox.Show("Invalid Rating Format.");
            }

            if (prodRating > 0 && prodRating < 11)
            {
                prodName = prodNameListBox.Text;

                prodList[prodCount] = prodName;
                ratingList[prodCount] = prodRating;

                prodCount++;
                textBoxProdCount.Text = prodCount.ToString();

                if (prodCount > 5) buttonUpdate.Enabled = false;
            }
        }
    }
}
