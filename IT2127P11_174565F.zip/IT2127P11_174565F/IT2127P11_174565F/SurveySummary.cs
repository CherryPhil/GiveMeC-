﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT2127P11_174565F
{
    public partial class SurveySummary : Form
    {
        public SurveySummary()
        {
            InitializeComponent();
        }

        private void SurveySummary_Load(object sender, EventArgs e)
        {
            string[] prodList = SurveyForm.ProdList;
            int[] ratingList = SurveyForm.RatingList;
            string item;

            //display the product and grade in listbox
            for (int i=0; i<5; i++)
            {
                item = prodList[i] + ": " + ratingList[i].ToString();
                listBoxDisplay.Items.Add(item);
            }

            //find the highest rated product
            int idxHigh = 0, highest = ratingList[0];

            for (int i=1; i<5; i++)
            {
                if (ratingList[i] > highest)
                {
                    highest = ratingList[i]; idxHigh = i;
                }
            }

            //Display the highest rated product and rating
            textBoxHighName.Text = prodList[idxHigh];
            textBoxHighRate.Text = highest.ToString();
        }
    }
}
