﻿namespace IT2127P11_174565F
{
    partial class SurveyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nYPStoreDataSet = new IT2127P11_174565F.NYPStoreDataSet();
            this.productsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productsTableAdapter = new IT2127P11_174565F.NYPStoreDataSetTableAdapters.ProductsTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxRating = new System.Windows.Forms.TextBox();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxProdCount = new System.Windows.Forms.TextBox();
            this.tableAdapterManager = new IT2127P11_174565F.NYPStoreDataSetTableAdapters.TableAdapterManager();
            this.prodNameListBox = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.nYPStoreDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(416, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select 5 products and give your rating in the scale of 1-10.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(411, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Give the product that you like the most the highest rating.";
            // 
            // nYPStoreDataSet
            // 
            this.nYPStoreDataSet.DataSetName = "NYPStoreDataSet";
            this.nYPStoreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productsBindingSource
            // 
            this.productsBindingSource.DataMember = "Products";
            this.productsBindingSource.DataSource = this.nYPStoreDataSet;
            // 
            // productsTableAdapter
            // 
            this.productsTableAdapter.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(273, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Rating";
            // 
            // textBoxRating
            // 
            this.textBoxRating.Location = new System.Drawing.Point(277, 141);
            this.textBoxRating.Name = "textBoxRating";
            this.textBoxRating.Size = new System.Drawing.Size(124, 26);
            this.textBoxRating.TabIndex = 4;
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Location = new System.Drawing.Point(277, 185);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(124, 36);
            this.buttonUpdate.TabIndex = 5;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(278, 243);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Product Count: ";
            // 
            // textBoxProdCount
            // 
            this.textBoxProdCount.Location = new System.Drawing.Point(403, 240);
            this.textBoxProdCount.Name = "textBoxProdCount";
            this.textBoxProdCount.ReadOnly = true;
            this.textBoxProdCount.Size = new System.Drawing.Size(76, 26);
            this.textBoxProdCount.TabIndex = 7;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CustomersTableAdapter = null;
            this.tableAdapterManager.OrdersTableAdapter = null;
            this.tableAdapterManager.ProductsTableAdapter = this.productsTableAdapter;
            this.tableAdapterManager.UpdateOrder = IT2127P11_174565F.NYPStoreDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // prodNameListBox
            // 
            this.prodNameListBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.productsBindingSource, "prodName", true));
            this.prodNameListBox.DataSource = this.productsBindingSource;
            this.prodNameListBox.DisplayMember = "prodName";
            this.prodNameListBox.FormattingEnabled = true;
            this.prodNameListBox.ItemHeight = 20;
            this.prodNameListBox.Location = new System.Drawing.Point(33, 108);
            this.prodNameListBox.Name = "prodNameListBox";
            this.prodNameListBox.Size = new System.Drawing.Size(202, 164);
            this.prodNameListBox.TabIndex = 8;
            this.prodNameListBox.ValueMember = "prodName";
            // 
            // SurveyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 303);
            this.Controls.Add(this.prodNameListBox);
            this.Controls.Add(this.textBoxProdCount);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonUpdate);
            this.Controls.Add(this.textBoxRating);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "SurveyForm";
            this.Text = "SurveyForm";
            this.Load += new System.EventHandler(this.SurveyForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nYPStoreDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private NYPStoreDataSet nYPStoreDataSet;
        private System.Windows.Forms.BindingSource productsBindingSource;
        private NYPStoreDataSetTableAdapters.ProductsTableAdapter productsTableAdapter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxRating;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxProdCount;
        private NYPStoreDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ListBox prodNameListBox;
    }
}