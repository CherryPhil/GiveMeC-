﻿namespace IT2127P11_174565F
{
    partial class SurveySummary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxDisplay = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxHighName = new System.Windows.Forms.TextBox();
            this.textBoxHighRate = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // listBoxDisplay
            // 
            this.listBoxDisplay.FormattingEnabled = true;
            this.listBoxDisplay.ItemHeight = 20;
            this.listBoxDisplay.Location = new System.Drawing.Point(36, 46);
            this.listBoxDisplay.Name = "listBoxDisplay";
            this.listBoxDisplay.Size = new System.Drawing.Size(447, 204);
            this.listBoxDisplay.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 277);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Highest Rating Product:";
            // 
            // textBoxHighName
            // 
            this.textBoxHighName.Location = new System.Drawing.Point(260, 271);
            this.textBoxHighName.Name = "textBoxHighName";
            this.textBoxHighName.Size = new System.Drawing.Size(100, 26);
            this.textBoxHighName.TabIndex = 2;
            // 
            // textBoxHighRate
            // 
            this.textBoxHighRate.Location = new System.Drawing.Point(406, 271);
            this.textBoxHighRate.Name = "textBoxHighRate";
            this.textBoxHighRate.Size = new System.Drawing.Size(77, 26);
            this.textBoxHighRate.TabIndex = 3;
            // 
            // SurveySummary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 333);
            this.Controls.Add(this.textBoxHighRate);
            this.Controls.Add(this.textBoxHighName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxDisplay);
            this.Name = "SurveySummary";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SurveySummary";
            this.Load += new System.EventHandler(this.SurveySummary_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxDisplay;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxHighName;
        private System.Windows.Forms.TextBox textBoxHighRate;
    }
}