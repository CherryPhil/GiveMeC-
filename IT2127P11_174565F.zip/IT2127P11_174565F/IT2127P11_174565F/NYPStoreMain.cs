﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT2127P11_174565F
{
    public partial class NYPStoreMain : Form
    {
        public NYPStoreMain()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'nYPStoreDataSet1.Products' table. You can move, or remove it, as needed.
            this.productsTableAdapter.Fill(this.nYPStoreDataSet1.Products);

        }

        private void viewProductDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductDetails newForm = new ProductDetails();
            newForm.ShowDialog();

        }

        private void enterSurveyDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SurveyForm newForm = new SurveyForm();
            newForm.Show();
        }

        private void viewSurveySummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SurveySummary newForm = new SurveySummary();
            newForm.ShowDialog();
        }
    }
}
