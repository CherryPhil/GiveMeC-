﻿namespace IT2127P11_174565F
{
    partial class ProductDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label prodIDLabel;
            System.Windows.Forms.Label prodNameLabel;
            System.Windows.Forms.Label prodDescLabel;
            System.Windows.Forms.Label prodCategoryLabel;
            System.Windows.Forms.Label priceLabel;
            System.Windows.Forms.Label stockQtyLabel;
            this.nYPStoreDataSet = new IT2127P11_174565F.NYPStoreDataSet();
            this.productsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productsTableAdapter = new IT2127P11_174565F.NYPStoreDataSetTableAdapters.ProductsTableAdapter();
            this.tableAdapterManager = new IT2127P11_174565F.NYPStoreDataSetTableAdapters.TableAdapterManager();
            this.prodIDTextBox = new System.Windows.Forms.TextBox();
            this.prodNameComboBox = new System.Windows.Forms.ComboBox();
            this.prodDescTextBox = new System.Windows.Forms.TextBox();
            this.prodCategoryTextBox = new System.Windows.Forms.TextBox();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.stockQtyTextBox = new System.Windows.Forms.TextBox();
            this.productsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.productsBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            prodIDLabel = new System.Windows.Forms.Label();
            prodNameLabel = new System.Windows.Forms.Label();
            prodDescLabel = new System.Windows.Forms.Label();
            prodCategoryLabel = new System.Windows.Forms.Label();
            priceLabel = new System.Windows.Forms.Label();
            stockQtyLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nYPStoreDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // nYPStoreDataSet
            // 
            this.nYPStoreDataSet.DataSetName = "NYPStoreDataSet";
            this.nYPStoreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productsBindingSource
            // 
            this.productsBindingSource.DataMember = "Products";
            this.productsBindingSource.DataSource = this.nYPStoreDataSet;
            // 
            // productsTableAdapter
            // 
            this.productsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CustomersTableAdapter = null;
            this.tableAdapterManager.OrdersTableAdapter = null;
            this.tableAdapterManager.ProductsTableAdapter = this.productsTableAdapter;
            this.tableAdapterManager.UpdateOrder = IT2127P11_174565F.NYPStoreDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // prodIDLabel
            // 
            prodIDLabel.AutoSize = true;
            prodIDLabel.Location = new System.Drawing.Point(60, 122);
            prodIDLabel.Name = "prodIDLabel";
            prodIDLabel.Size = new System.Drawing.Size(66, 20);
            prodIDLabel.TabIndex = 0;
            prodIDLabel.Text = "prod ID:";
            // 
            // prodIDTextBox
            // 
            this.prodIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "prodID", true));
            this.prodIDTextBox.Location = new System.Drawing.Point(179, 119);
            this.prodIDTextBox.Name = "prodIDTextBox";
            this.prodIDTextBox.Size = new System.Drawing.Size(160, 26);
            this.prodIDTextBox.TabIndex = 1;
            // 
            // prodNameLabel
            // 
            prodNameLabel.AutoSize = true;
            prodNameLabel.Location = new System.Drawing.Point(60, 63);
            prodNameLabel.Name = "prodNameLabel";
            prodNameLabel.Size = new System.Drawing.Size(91, 20);
            prodNameLabel.TabIndex = 2;
            prodNameLabel.Text = "prod Name:";
            // 
            // prodNameComboBox
            // 
            this.prodNameComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "prodName", true));
            this.prodNameComboBox.DataSource = this.productsBindingSource;
            this.prodNameComboBox.DisplayMember = "prodName";
            this.prodNameComboBox.FormattingEnabled = true;
            this.prodNameComboBox.Location = new System.Drawing.Point(179, 60);
            this.prodNameComboBox.Name = "prodNameComboBox";
            this.prodNameComboBox.Size = new System.Drawing.Size(160, 28);
            this.prodNameComboBox.TabIndex = 3;
            this.prodNameComboBox.ValueMember = "prodID";
            // 
            // prodDescLabel
            // 
            prodDescLabel.AutoSize = true;
            prodDescLabel.Location = new System.Drawing.Point(60, 154);
            prodDescLabel.Name = "prodDescLabel";
            prodDescLabel.Size = new System.Drawing.Size(86, 20);
            prodDescLabel.TabIndex = 4;
            prodDescLabel.Text = "prod Desc:";
            // 
            // prodDescTextBox
            // 
            this.prodDescTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "prodDesc", true));
            this.prodDescTextBox.Location = new System.Drawing.Point(179, 151);
            this.prodDescTextBox.Name = "prodDescTextBox";
            this.prodDescTextBox.Size = new System.Drawing.Size(160, 26);
            this.prodDescTextBox.TabIndex = 5;
            // 
            // prodCategoryLabel
            // 
            prodCategoryLabel.AutoSize = true;
            prodCategoryLabel.Location = new System.Drawing.Point(60, 186);
            prodCategoryLabel.Name = "prodCategoryLabel";
            prodCategoryLabel.Size = new System.Drawing.Size(113, 20);
            prodCategoryLabel.TabIndex = 6;
            prodCategoryLabel.Text = "prod Category:";
            // 
            // prodCategoryTextBox
            // 
            this.prodCategoryTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "prodCategory", true));
            this.prodCategoryTextBox.Location = new System.Drawing.Point(179, 183);
            this.prodCategoryTextBox.Name = "prodCategoryTextBox";
            this.prodCategoryTextBox.Size = new System.Drawing.Size(160, 26);
            this.prodCategoryTextBox.TabIndex = 7;
            // 
            // priceLabel
            // 
            priceLabel.AutoSize = true;
            priceLabel.Location = new System.Drawing.Point(60, 218);
            priceLabel.Name = "priceLabel";
            priceLabel.Size = new System.Drawing.Size(47, 20);
            priceLabel.TabIndex = 8;
            priceLabel.Text = "price:";
            // 
            // priceTextBox
            // 
            this.priceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "price", true));
            this.priceTextBox.Location = new System.Drawing.Point(179, 215);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(160, 26);
            this.priceTextBox.TabIndex = 9;
            // 
            // stockQtyLabel
            // 
            stockQtyLabel.AutoSize = true;
            stockQtyLabel.Location = new System.Drawing.Point(60, 250);
            stockQtyLabel.Name = "stockQtyLabel";
            stockQtyLabel.Size = new System.Drawing.Size(79, 20);
            stockQtyLabel.TabIndex = 10;
            stockQtyLabel.Text = "stock Qty:";
            // 
            // stockQtyTextBox
            // 
            this.stockQtyTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productsBindingSource, "stockQty", true));
            this.stockQtyTextBox.Location = new System.Drawing.Point(179, 247);
            this.stockQtyTextBox.Name = "stockQtyTextBox";
            this.stockQtyTextBox.Size = new System.Drawing.Size(160, 26);
            this.stockQtyTextBox.TabIndex = 11;
            // 
            // productsBindingSource1
            // 
            this.productsBindingSource1.DataMember = "Products";
            this.productsBindingSource1.DataSource = this.nYPStoreDataSet;
            // 
            // productsBindingSource2
            // 
            this.productsBindingSource2.DataMember = "Products";
            this.productsBindingSource2.DataSource = this.nYPStoreDataSet;
            // 
            // ProductDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 391);
            this.Controls.Add(prodIDLabel);
            this.Controls.Add(this.prodIDTextBox);
            this.Controls.Add(prodNameLabel);
            this.Controls.Add(this.prodNameComboBox);
            this.Controls.Add(prodDescLabel);
            this.Controls.Add(this.prodDescTextBox);
            this.Controls.Add(prodCategoryLabel);
            this.Controls.Add(this.prodCategoryTextBox);
            this.Controls.Add(priceLabel);
            this.Controls.Add(this.priceTextBox);
            this.Controls.Add(stockQtyLabel);
            this.Controls.Add(this.stockQtyTextBox);
            this.Name = "ProductDetails";
            this.Text = "View Product Details";
            this.Load += new System.EventHandler(this.ProductDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nYPStoreDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private NYPStoreDataSet nYPStoreDataSet;
        private System.Windows.Forms.BindingSource productsBindingSource;
        private NYPStoreDataSetTableAdapters.ProductsTableAdapter productsTableAdapter;
        private NYPStoreDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox prodIDTextBox;
        private System.Windows.Forms.ComboBox prodNameComboBox;
        private System.Windows.Forms.TextBox prodDescTextBox;
        private System.Windows.Forms.TextBox prodCategoryTextBox;
        private System.Windows.Forms.TextBox priceTextBox;
        private System.Windows.Forms.TextBox stockQtyTextBox;
        private System.Windows.Forms.BindingSource productsBindingSource1;
        private System.Windows.Forms.BindingSource productsBindingSource2;
    }
}