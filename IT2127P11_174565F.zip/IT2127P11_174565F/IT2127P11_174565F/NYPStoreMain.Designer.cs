﻿namespace IT2127P11_174565F
{
    partial class NYPStoreMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.viewProductDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enterSurveyDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewSurveySummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.productsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nYPStoreDataSet1 = new IT2127P11_174565F.NYPStoreDataSet1();
            this.productsTableAdapter = new IT2127P11_174565F.NYPStoreDataSet1TableAdapters.ProductsTableAdapter();
            this.prodNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodDescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodCategoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nYPStoreDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewProductDetailsToolStripMenuItem,
            this.enterSurveyDataToolStripMenuItem,
            this.viewSurveySummaryToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(630, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // viewProductDetailsToolStripMenuItem
            // 
            this.viewProductDetailsToolStripMenuItem.Name = "viewProductDetailsToolStripMenuItem";
            this.viewProductDetailsToolStripMenuItem.Size = new System.Drawing.Size(186, 29);
            this.viewProductDetailsToolStripMenuItem.Text = "&View Product Details";
            this.viewProductDetailsToolStripMenuItem.Click += new System.EventHandler(this.viewProductDetailsToolStripMenuItem_Click);
            // 
            // enterSurveyDataToolStripMenuItem
            // 
            this.enterSurveyDataToolStripMenuItem.Name = "enterSurveyDataToolStripMenuItem";
            this.enterSurveyDataToolStripMenuItem.Size = new System.Drawing.Size(164, 29);
            this.enterSurveyDataToolStripMenuItem.Text = "&Enter Survey Data";
            this.enterSurveyDataToolStripMenuItem.Click += new System.EventHandler(this.enterSurveyDataToolStripMenuItem_Click);
            // 
            // viewSurveySummaryToolStripMenuItem
            // 
            this.viewSurveySummaryToolStripMenuItem.Name = "viewSurveySummaryToolStripMenuItem";
            this.viewSurveySummaryToolStripMenuItem.Size = new System.Drawing.Size(200, 29);
            this.viewSurveySummaryToolStripMenuItem.Text = "&View Survey Summary";
            this.viewSurveySummaryToolStripMenuItem.Click += new System.EventHandler(this.viewSurveySummaryToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prodNameDataGridViewTextBoxColumn,
            this.prodDescDataGridViewTextBoxColumn,
            this.prodCategoryDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.productsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 69);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(606, 299);
            this.dataGridView1.TabIndex = 1;
            // 
            // productsBindingSource
            // 
            this.productsBindingSource.DataMember = "Products";
            this.productsBindingSource.DataSource = this.nYPStoreDataSet1;
            // 
            // nYPStoreDataSet1
            // 
            this.nYPStoreDataSet1.DataSetName = "NYPStoreDataSet1";
            this.nYPStoreDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productsTableAdapter
            // 
            this.productsTableAdapter.ClearBeforeFill = true;
            // 
            // prodNameDataGridViewTextBoxColumn
            // 
            this.prodNameDataGridViewTextBoxColumn.DataPropertyName = "prodName";
            this.prodNameDataGridViewTextBoxColumn.HeaderText = "Product Name";
            this.prodNameDataGridViewTextBoxColumn.Name = "prodNameDataGridViewTextBoxColumn";
            this.prodNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.prodNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // prodDescDataGridViewTextBoxColumn
            // 
            this.prodDescDataGridViewTextBoxColumn.DataPropertyName = "prodDesc";
            this.prodDescDataGridViewTextBoxColumn.HeaderText = "Product Description";
            this.prodDescDataGridViewTextBoxColumn.Name = "prodDescDataGridViewTextBoxColumn";
            this.prodDescDataGridViewTextBoxColumn.ReadOnly = true;
            this.prodDescDataGridViewTextBoxColumn.Width = 150;
            // 
            // prodCategoryDataGridViewTextBoxColumn
            // 
            this.prodCategoryDataGridViewTextBoxColumn.DataPropertyName = "prodCategory";
            this.prodCategoryDataGridViewTextBoxColumn.HeaderText = "Category";
            this.prodCategoryDataGridViewTextBoxColumn.Name = "prodCategoryDataGridViewTextBoxColumn";
            this.prodCategoryDataGridViewTextBoxColumn.ReadOnly = true;
            this.prodCategoryDataGridViewTextBoxColumn.Width = 150;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            dataGridViewCellStyle1.Format = "C2";
            dataGridViewCellStyle1.NullValue = "0";
            this.priceDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            this.priceDataGridViewTextBoxColumn.Width = 150;
            // 
            // NYPStoreMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 545);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "NYPStoreMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NYP Store Main";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nYPStoreDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem viewProductDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enterSurveyDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewSurveySummaryToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private NYPStoreDataSet1 nYPStoreDataSet1;
        private System.Windows.Forms.BindingSource productsBindingSource;
        private NYPStoreDataSet1TableAdapters.ProductsTableAdapter productsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodDescDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodCategoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
    }
}

