﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pract9
{
    public partial class Form1 : Form
    {
        public static string userInput { get; set; }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            userInput = textBoxInput.Text;

            Form2 newform = new Form2();
            newform.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 newForm = new Form3();

            newForm.userInputF3 = textBoxInput.Text;
            newForm.Show();
        }

        private void openForm2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            userInput = textBoxInput.Text;

            Form2 newForm = new Form2();
            newForm.ShowDialog();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void openForm3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 newForm = new Form3();

            newForm.userInputF3 = textBoxInput.Text;
            newForm.Show();
        }
    }
}
