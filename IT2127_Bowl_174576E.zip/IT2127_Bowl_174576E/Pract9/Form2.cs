﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pract9
{
    public partial class Form2 : Form
    {
        public static string First { get; set; }
        public static string Second { get; set; }
        public static string Third { get; set; }

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // Bowler 1
            txtBowler1.Text = Form1.bowler1;
            txtBowler1Game1.Text = Form1.bowler1Scores[0].ToString();
            txtBowler1Game2.Text = Form1.bowler1Scores[1].ToString();
            txtBowler1Game3.Text = Form1.bowler1Scores[2].ToString();

            // Bowler 2
            txtBowler2.Text = Form1.bowler2;
            txtBowler2Game1.Text = Form1.bowler2Scores[0].ToString();
            txtBowler2Game2.Text = Form1.bowler2Scores[1].ToString();
            txtBowler2Game3.Text = Form1.bowler2Scores[2].ToString();

            // Bowler 3
            txtBowler3.Text = Form1.bowler3;
            txtBowler3Game1.Text = Form1.bowler3Scores[0].ToString();
            txtBowler3Game2.Text = Form1.bowler3Scores[1].ToString();
            txtBowler3Game3.Text = Form1.bowler3Scores[2].ToString();

            // Bowler 4
            txtBowler4.Text = Form1.bowler4;
            txtBowler4Game1.Text = Form1.bowler4Scores[0].ToString();
            txtBowler4Game2.Text = Form1.bowler4Scores[1].ToString();
            txtBowler4Game3.Text = Form1.bowler4Scores[2].ToString();

            // Bowler 5
            txtBowler5.Text = Form1.bowler5;
            txtBowler5Game1.Text = Form1.bowler5Scores[0].ToString();
            txtBowler5Game2.Text = Form1.bowler5Scores[1].ToString();
            txtBowler5Game3.Text = Form1.bowler5Scores[2].ToString();

            // Bowler 6
            txtBowler6.Text = Form1.bowler6;
            txtBowler6Game1.Text = Form1.bowler6Scores[0].ToString();
            txtBowler6Game2.Text = Form1.bowler6Scores[1].ToString();
            txtBowler6Game3.Text = Form1.bowler6Scores[2].ToString();

            // Put total score in an array
            int Bowler1Total, Bowler2Total, Bowler3Total, Bowler4Total, Bowler5Total, Bowler6Total;
            Bowler1Total = Form1.bowler1Scores.Sum();
            Bowler2Total = Form1.bowler2Scores.Sum();
            Bowler3Total = Form1.bowler3Scores.Sum();
            Bowler4Total = Form1.bowler4Scores.Sum();
            Bowler5Total = Form1.bowler5Scores.Sum();
            Bowler6Total = Form1.bowler6Scores.Sum();

            // Sort to ascending order
            int[] TotalScores = { Bowler1Total, Bowler2Total, Bowler3Total, Bowler4Total, Bowler5Total, Bowler6Total };
            Array.Sort(TotalScores);

            // First Place
            if (Bowler1Total == TotalScores[5])
            {
                textFirst.Text = Form1.bowler1;
                First = Form1.bowler1;
            }
            else if (Bowler2Total == TotalScores[5])
            {
                textFirst.Text = Form1.bowler2;
                First = Form1.bowler2;
            }
            else if (Bowler3Total == TotalScores[5])
            {
                textFirst.Text = Form1.bowler3;
                First = Form1.bowler3;
            }
            else if (Bowler4Total == TotalScores[5])
            {
                textFirst.Text = Form1.bowler4;
                First = Form1.bowler4;
            }
            else if (Bowler5Total == TotalScores[5])
            {
                textFirst.Text = Form1.bowler5;
                First = Form1.bowler5;
            }
            else if (Bowler6Total == TotalScores[5])
            {
                textFirst.Text = Form1.bowler6;
                First = Form1.bowler6;
            }

            // Second Place
            if (Bowler1Total == TotalScores[4]) {
                textSecond.Text = Form1.bowler1;
                Second = Form1.bowler1;
            }
            else if (Bowler2Total == TotalScores[4])
            {
                textSecond.Text = Form1.bowler2;
                Second = Form1.bowler2;
            }
            else if (Bowler3Total == TotalScores[4])
            {
                textSecond.Text = Form1.bowler3;
                Second = Form1.bowler3;
            }
            else if (Bowler4Total == TotalScores[4])
            {
                textSecond.Text = Form1.bowler4;
                Second = Form1.bowler4;
            }
            else if (Bowler5Total == TotalScores[4])
            {
                textSecond.Text = Form1.bowler5;
                Second = Form1.bowler5;
            }
            else if (Bowler6Total == TotalScores[4])
            {
                textSecond.Text = Form1.bowler6;
                Second = Form1.bowler6;
            }

            // Third Place
            if (Bowler1Total == TotalScores[3])
            {
                textThird.Text = Form1.bowler1;
                Third = Form1.bowler1;
            }
            else if (Bowler2Total == TotalScores[3])
            {
                textThird.Text = Form1.bowler2;
                Third = Form1.bowler2;
            }
            else if (Bowler3Total == TotalScores[3])
            {
                textThird.Text = Form1.bowler3;
                Third = Form1.bowler3;
            }
            else if (Bowler4Total == TotalScores[3])
            {
                textThird.Text = Form1.bowler4;
                Third = Form1.bowler4;
            }
            else if (Bowler5Total == TotalScores[3])
            {
                textThird.Text = Form1.bowler5;
                Third = Form1.bowler5;
            }
            else if (Bowler6Total == TotalScores[3])
            {
                textThird.Text = Form1.bowler6;
                Third = Form1.bowler6;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
