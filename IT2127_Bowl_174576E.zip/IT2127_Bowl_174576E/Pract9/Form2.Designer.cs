﻿namespace Pract9
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtBowler4Game3 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtBowler4Game2 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtBowler4Game1 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtBowler4 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtBowler2Game3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBowler2Game2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBowler2Game1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBowler2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtBowler5Game3 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtBowler5Game2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtBowler5Game1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtBowler5 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtBowler3Game3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtBowler3Game2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtBowler3Game1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtBowler3 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtBowler6Game3 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtBowler6Game2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBowler6Game1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtBowler6 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtBowler1Game3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBowler1Game2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBowler1Game1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBowler1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textFirst = new System.Windows.Forms.TextBox();
            this.textSecond = new System.Windows.Forms.TextBox();
            this.textThird = new System.Windows.Forms.TextBox();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(872, 353);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(60, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 24);
            this.label5.TabIndex = 23;
            this.label5.Text = "Bowler Scores";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtBowler4Game3);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.txtBowler4Game2);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.txtBowler4Game1);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.txtBowler4);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Location = new System.Drawing.Point(64, 235);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(210, 141);
            this.groupBox6.TabIndex = 71;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Bowler #4";
            // 
            // txtBowler4Game3
            // 
            this.txtBowler4Game3.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler4Game3.Location = new System.Drawing.Point(80, 99);
            this.txtBowler4Game3.Name = "txtBowler4Game3";
            this.txtBowler4Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler4Game3.TabIndex = 39;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(19, 102);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(44, 13);
            this.label22.TabIndex = 38;
            this.label22.Text = "Game 3";
            // 
            // txtBowler4Game2
            // 
            this.txtBowler4Game2.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler4Game2.Location = new System.Drawing.Point(80, 73);
            this.txtBowler4Game2.Name = "txtBowler4Game2";
            this.txtBowler4Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler4Game2.TabIndex = 37;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(19, 76);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 13);
            this.label23.TabIndex = 36;
            this.label23.Text = "Game 2";
            // 
            // txtBowler4Game1
            // 
            this.txtBowler4Game1.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler4Game1.Location = new System.Drawing.Point(80, 47);
            this.txtBowler4Game1.Name = "txtBowler4Game1";
            this.txtBowler4Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler4Game1.TabIndex = 35;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(19, 50);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(44, 13);
            this.label24.TabIndex = 34;
            this.label24.Text = "Game 1";
            // 
            // txtBowler4
            // 
            this.txtBowler4.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler4.Location = new System.Drawing.Point(80, 21);
            this.txtBowler4.Name = "txtBowler4";
            this.txtBowler4.Size = new System.Drawing.Size(100, 20);
            this.txtBowler4.TabIndex = 33;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(19, 24);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(35, 13);
            this.label25.TabIndex = 32;
            this.label25.Text = "Name";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtBowler2Game3);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtBowler2Game2);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txtBowler2Game1);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txtBowler2);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Location = new System.Drawing.Point(295, 79);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(210, 141);
            this.groupBox3.TabIndex = 89;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Bowler #2";
            // 
            // txtBowler2Game3
            // 
            this.txtBowler2Game3.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler2Game3.Location = new System.Drawing.Point(80, 99);
            this.txtBowler2Game3.Name = "txtBowler2Game3";
            this.txtBowler2Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler2Game3.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 102);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "Game 3";
            // 
            // txtBowler2Game2
            // 
            this.txtBowler2Game2.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler2Game2.Location = new System.Drawing.Point(80, 73);
            this.txtBowler2Game2.Name = "txtBowler2Game2";
            this.txtBowler2Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler2Game2.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 36;
            this.label7.Text = "Game 2";
            // 
            // txtBowler2Game1
            // 
            this.txtBowler2Game1.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler2Game1.Location = new System.Drawing.Point(80, 47);
            this.txtBowler2Game1.Name = "txtBowler2Game1";
            this.txtBowler2Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler2Game1.TabIndex = 35;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 34;
            this.label8.Text = "Game 1";
            // 
            // txtBowler2
            // 
            this.txtBowler2.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler2.Location = new System.Drawing.Point(80, 21);
            this.txtBowler2.Name = "txtBowler2";
            this.txtBowler2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler2.TabIndex = 33;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 32;
            this.label9.Text = "Name";
            // 
            // txtBowler5Game3
            // 
            this.txtBowler5Game3.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler5Game3.Location = new System.Drawing.Point(375, 334);
            this.txtBowler5Game3.Name = "txtBowler5Game3";
            this.txtBowler5Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler5Game3.TabIndex = 87;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(314, 337);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(44, 13);
            this.label18.TabIndex = 86;
            this.label18.Text = "Game 3";
            // 
            // txtBowler5Game2
            // 
            this.txtBowler5Game2.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler5Game2.Location = new System.Drawing.Point(375, 308);
            this.txtBowler5Game2.Name = "txtBowler5Game2";
            this.txtBowler5Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler5Game2.TabIndex = 85;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(314, 311);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 13);
            this.label19.TabIndex = 84;
            this.label19.Text = "Game 2";
            // 
            // txtBowler5Game1
            // 
            this.txtBowler5Game1.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler5Game1.Location = new System.Drawing.Point(375, 282);
            this.txtBowler5Game1.Name = "txtBowler5Game1";
            this.txtBowler5Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler5Game1.TabIndex = 83;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(314, 285);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(44, 13);
            this.label20.TabIndex = 82;
            this.label20.Text = "Game 1";
            // 
            // txtBowler5
            // 
            this.txtBowler5.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler5.Location = new System.Drawing.Point(375, 256);
            this.txtBowler5.Name = "txtBowler5";
            this.txtBowler5.Size = new System.Drawing.Size(100, 20);
            this.txtBowler5.TabIndex = 81;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(314, 259);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 13);
            this.label21.TabIndex = 80;
            this.label21.Text = "Name";
            // 
            // groupBox5
            // 
            this.groupBox5.Location = new System.Drawing.Point(295, 235);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(210, 141);
            this.groupBox5.TabIndex = 88;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Bowler #5";
            // 
            // txtBowler3Game3
            // 
            this.txtBowler3Game3.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler3Game3.Location = new System.Drawing.Point(608, 178);
            this.txtBowler3Game3.Name = "txtBowler3Game3";
            this.txtBowler3Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler3Game3.TabIndex = 78;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(547, 181);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 13);
            this.label14.TabIndex = 77;
            this.label14.Text = "Game 3";
            // 
            // txtBowler3Game2
            // 
            this.txtBowler3Game2.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler3Game2.Location = new System.Drawing.Point(608, 152);
            this.txtBowler3Game2.Name = "txtBowler3Game2";
            this.txtBowler3Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler3Game2.TabIndex = 76;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(547, 155);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 13);
            this.label15.TabIndex = 75;
            this.label15.Text = "Game 2";
            // 
            // txtBowler3Game1
            // 
            this.txtBowler3Game1.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler3Game1.Location = new System.Drawing.Point(608, 126);
            this.txtBowler3Game1.Name = "txtBowler3Game1";
            this.txtBowler3Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler3Game1.TabIndex = 74;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(547, 129);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 13);
            this.label16.TabIndex = 73;
            this.label16.Text = "Game 1";
            // 
            // txtBowler3
            // 
            this.txtBowler3.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler3.Location = new System.Drawing.Point(608, 100);
            this.txtBowler3.Name = "txtBowler3";
            this.txtBowler3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler3.TabIndex = 72;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(547, 103);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 13);
            this.label17.TabIndex = 70;
            this.label17.Text = "Name";
            // 
            // groupBox4
            // 
            this.groupBox4.Location = new System.Drawing.Point(528, 79);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(210, 141);
            this.groupBox4.TabIndex = 79;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Bowler #3";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtBowler6Game3);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtBowler6Game2);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtBowler6Game1);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtBowler6);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Location = new System.Drawing.Point(528, 235);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(210, 141);
            this.groupBox2.TabIndex = 69;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bowler #6";
            // 
            // txtBowler6Game3
            // 
            this.txtBowler6Game3.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler6Game3.Location = new System.Drawing.Point(80, 99);
            this.txtBowler6Game3.Name = "txtBowler6Game3";
            this.txtBowler6Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler6Game3.TabIndex = 39;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 38;
            this.label10.Text = "Game 3";
            // 
            // txtBowler6Game2
            // 
            this.txtBowler6Game2.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler6Game2.Location = new System.Drawing.Point(80, 73);
            this.txtBowler6Game2.Name = "txtBowler6Game2";
            this.txtBowler6Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler6Game2.TabIndex = 37;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 36;
            this.label11.Text = "Game 2";
            // 
            // txtBowler6Game1
            // 
            this.txtBowler6Game1.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler6Game1.Location = new System.Drawing.Point(80, 47);
            this.txtBowler6Game1.Name = "txtBowler6Game1";
            this.txtBowler6Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler6Game1.TabIndex = 35;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 13);
            this.label12.TabIndex = 34;
            this.label12.Text = "Game 1";
            // 
            // txtBowler6
            // 
            this.txtBowler6.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler6.Location = new System.Drawing.Point(80, 21);
            this.txtBowler6.Name = "txtBowler6";
            this.txtBowler6.Size = new System.Drawing.Size(100, 20);
            this.txtBowler6.TabIndex = 33;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 13);
            this.label13.TabIndex = 32;
            this.label13.Text = "Name";
            // 
            // txtBowler1Game3
            // 
            this.txtBowler1Game3.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler1Game3.Location = new System.Drawing.Point(144, 178);
            this.txtBowler1Game3.Name = "txtBowler1Game3";
            this.txtBowler1Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler1Game3.TabIndex = 67;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(83, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 66;
            this.label4.Text = "Game 3";
            // 
            // txtBowler1Game2
            // 
            this.txtBowler1Game2.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler1Game2.Location = new System.Drawing.Point(144, 152);
            this.txtBowler1Game2.Name = "txtBowler1Game2";
            this.txtBowler1Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler1Game2.TabIndex = 65;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(83, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 64;
            this.label3.Text = "Game 2";
            // 
            // txtBowler1Game1
            // 
            this.txtBowler1Game1.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler1Game1.Location = new System.Drawing.Point(144, 126);
            this.txtBowler1Game1.Name = "txtBowler1Game1";
            this.txtBowler1Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler1Game1.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(83, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 62;
            this.label1.Text = "Game 1";
            // 
            // txtBowler1
            // 
            this.txtBowler1.BackColor = System.Drawing.SystemColors.Control;
            this.txtBowler1.Location = new System.Drawing.Point(144, 100);
            this.txtBowler1.Name = "txtBowler1";
            this.txtBowler1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler1.TabIndex = 61;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(83, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 60;
            this.label2.Text = "Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(64, 79);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 141);
            this.groupBox1.TabIndex = 68;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bowler #1";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.textThird);
            this.groupBox7.Controls.Add(this.textSecond);
            this.groupBox7.Controls.Add(this.textFirst);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Location = new System.Drawing.Point(762, 79);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(201, 115);
            this.groupBox7.TabIndex = 90;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Top Scorers";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(18, 27);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(51, 13);
            this.label26.TabIndex = 0;
            this.label26.Text = "1st Place";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(18, 53);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 13);
            this.label27.TabIndex = 1;
            this.label27.Text = "2nd Place";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(17, 79);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(52, 13);
            this.label28.TabIndex = 2;
            this.label28.Text = "3rd Place";
            // 
            // textFirst
            // 
            this.textFirst.BackColor = System.Drawing.SystemColors.Control;
            this.textFirst.Location = new System.Drawing.Point(85, 24);
            this.textFirst.Name = "textFirst";
            this.textFirst.Size = new System.Drawing.Size(100, 20);
            this.textFirst.TabIndex = 91;
            // 
            // textSecond
            // 
            this.textSecond.BackColor = System.Drawing.SystemColors.Control;
            this.textSecond.Location = new System.Drawing.Point(85, 50);
            this.textSecond.Name = "textSecond";
            this.textSecond.Size = new System.Drawing.Size(100, 20);
            this.textSecond.TabIndex = 92;
            // 
            // textThird
            // 
            this.textThird.BackColor = System.Drawing.SystemColors.Control;
            this.textThird.Location = new System.Drawing.Point(85, 76);
            this.textThird.Name = "textThird";
            this.textThird.Size = new System.Drawing.Size(100, 20);
            this.textThird.TabIndex = 93;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(987, 409);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.txtBowler5Game3);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtBowler5Game2);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtBowler5Game1);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtBowler5);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.txtBowler3Game3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtBowler3Game2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtBowler3Game1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtBowler3);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txtBowler1Game3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtBowler1Game2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtBowler1Game1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBowler1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Name = "Form2";
            this.Text = "Bowler Scores";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtBowler4Game3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtBowler4Game2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtBowler4Game1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtBowler4;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtBowler2Game3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtBowler2Game2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBowler2Game1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBowler2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtBowler5Game3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtBowler5Game2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtBowler5Game1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtBowler5;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtBowler3Game3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtBowler3Game2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtBowler3Game1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtBowler3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtBowler6Game3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtBowler6Game2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtBowler6Game1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtBowler6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtBowler1Game3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBowler1Game2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBowler1Game1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBowler1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textThird;
        private System.Windows.Forms.TextBox textSecond;
        private System.Windows.Forms.TextBox textFirst;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
    }
}