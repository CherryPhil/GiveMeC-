﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pract9
{
    public partial class Form3 : Form
    {
        public string userInputF3 { get; set; }
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            txtFirst.Text = Form2.First;
            txtSecond.Text = Form2.Second;
            txtThird.Text = Form2.Third;

            // First
            if (Form2.First == Form1.bowler1)
            {
                txtFirstGame1.Text = Form1.bowler1Scores[0].ToString();
                txtFirstGame2.Text = Form1.bowler1Scores[1].ToString();
                txtFirstGame3.Text = Form1.bowler1Scores[2].ToString();
            }
            else if (Form2.First == Form1.bowler2)
            {
                txtFirstGame1.Text = Form1.bowler2Scores[0].ToString();
                txtFirstGame2.Text = Form1.bowler2Scores[1].ToString();
                txtFirstGame3.Text = Form1.bowler2Scores[2].ToString();
            }
            else if (Form2.First == Form1.bowler3)
            {
                txtFirstGame1.Text = Form1.bowler3Scores[0].ToString();
                txtFirstGame2.Text = Form1.bowler3Scores[1].ToString();
                txtFirstGame3.Text = Form1.bowler3Scores[2].ToString();
            }
            else if (Form2.First == Form1.bowler4)
            {
                txtFirstGame1.Text = Form1.bowler4Scores[0].ToString();
                txtFirstGame2.Text = Form1.bowler4Scores[1].ToString();
                txtFirstGame3.Text = Form1.bowler4Scores[2].ToString();
            }
            else if (Form2.First == Form1.bowler5)
            {
                txtFirstGame1.Text = Form1.bowler5Scores[0].ToString();
                txtFirstGame2.Text = Form1.bowler5Scores[1].ToString();
                txtFirstGame3.Text = Form1.bowler5Scores[2].ToString();
            }
            else if (Form2.First == Form1.bowler6)
            {
                txtFirstGame1.Text = Form1.bowler6Scores[0].ToString();
                txtFirstGame2.Text = Form1.bowler6Scores[1].ToString();
                txtFirstGame3.Text = Form1.bowler6Scores[2].ToString();
            }

            // Second
            if (Form2.Second == Form1.bowler1)
            {
                txtSecondGame1.Text = Form1.bowler1Scores[0].ToString();
                txtSecondGame2.Text = Form1.bowler1Scores[1].ToString();
                txtSecondGame3.Text = Form1.bowler1Scores[2].ToString();
            }
            else if (Form2.Second == Form1.bowler2)
            {
                txtSecondGame1.Text = Form1.bowler2Scores[0].ToString();
                txtSecondGame2.Text = Form1.bowler2Scores[1].ToString();
                txtSecondGame3.Text = Form1.bowler2Scores[2].ToString();
            }
            else if (Form2.Second == Form1.bowler3)
            {
                txtSecondGame1.Text = Form1.bowler3Scores[0].ToString();
                txtSecondGame2.Text = Form1.bowler3Scores[1].ToString();
                txtSecondGame3.Text = Form1.bowler3Scores[2].ToString();
            }
            else if (Form2.Second == Form1.bowler4)
            {
                txtSecondGame1.Text = Form1.bowler4Scores[0].ToString();
                txtSecondGame2.Text = Form1.bowler4Scores[1].ToString();
                txtSecondGame3.Text = Form1.bowler4Scores[2].ToString();
            }
            else if (Form2.Second == Form1.bowler5)
            {
                txtSecondGame1.Text = Form1.bowler5Scores[0].ToString();
                txtSecondGame2.Text = Form1.bowler5Scores[1].ToString();
                txtSecondGame3.Text = Form1.bowler5Scores[2].ToString();
            }
            else if (Form2.Second == Form1.bowler6)
            {
                txtSecondGame1.Text = Form1.bowler6Scores[0].ToString();
                txtSecondGame2.Text = Form1.bowler6Scores[1].ToString();
                txtSecondGame3.Text = Form1.bowler6Scores[2].ToString();
            }

            // Third
            if (Form2.Third == Form1.bowler1)
            {
                txtThirdGame1.Text = Form1.bowler1Scores[0].ToString();
                txtThirdGame2.Text = Form1.bowler1Scores[1].ToString();
                txtThirdGame3.Text = Form1.bowler1Scores[2].ToString();
            }
            else if (Form2.Third == Form1.bowler2)
            {
                txtThirdGame1.Text = Form1.bowler2Scores[0].ToString();
                txtThirdGame2.Text = Form1.bowler2Scores[1].ToString();
                txtThirdGame3.Text = Form1.bowler2Scores[2].ToString();
            }
            else if (Form2.Third == Form1.bowler3)
            {
                txtThirdGame1.Text = Form1.bowler3Scores[0].ToString();
                txtThirdGame2.Text = Form1.bowler3Scores[1].ToString();
                txtThirdGame3.Text = Form1.bowler3Scores[2].ToString();
            }
            else if (Form2.Third == Form1.bowler4)
            {
                txtThirdGame1.Text = Form1.bowler4Scores[0].ToString();
                txtThirdGame2.Text = Form1.bowler4Scores[1].ToString();
                txtThirdGame3.Text = Form1.bowler4Scores[2].ToString();
            }
            else if (Form2.Third == Form1.bowler5)
            {
                txtThirdGame1.Text = Form1.bowler5Scores[0].ToString();
                txtThirdGame2.Text = Form1.bowler5Scores[1].ToString();
                txtThirdGame3.Text = Form1.bowler5Scores[2].ToString();
            }
            else if (Form2.Third == Form1.bowler6)
            {
                txtThirdGame1.Text = Form1.bowler6Scores[0].ToString();
                txtThirdGame2.Text = Form1.bowler6Scores[1].ToString();
                txtFirstGame3.Text = Form1.bowler6Scores[2].ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
