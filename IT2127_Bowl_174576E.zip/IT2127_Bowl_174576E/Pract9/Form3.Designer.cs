﻿namespace Pract9
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtSecondGame3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSecondGame2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSecondGame1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSecond = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtThirdGame3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtThirdGame2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtThirdGame1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtThird = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtFirstGame3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFirstGame2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFirstGame1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFirst = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(675, 257);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(72, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 24);
            this.label5.TabIndex = 24;
            this.label5.Text = "Final Results";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtSecondGame3);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtSecondGame2);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txtSecondGame1);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txtSecond);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Location = new System.Drawing.Point(307, 92);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(210, 141);
            this.groupBox3.TabIndex = 108;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "2nd Place";
            // 
            // txtSecondGame3
            // 
            this.txtSecondGame3.BackColor = System.Drawing.SystemColors.Control;
            this.txtSecondGame3.Location = new System.Drawing.Point(80, 99);
            this.txtSecondGame3.Name = "txtSecondGame3";
            this.txtSecondGame3.Size = new System.Drawing.Size(100, 20);
            this.txtSecondGame3.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 102);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "Game 3";
            // 
            // txtSecondGame2
            // 
            this.txtSecondGame2.BackColor = System.Drawing.SystemColors.Control;
            this.txtSecondGame2.Location = new System.Drawing.Point(80, 73);
            this.txtSecondGame2.Name = "txtSecondGame2";
            this.txtSecondGame2.Size = new System.Drawing.Size(100, 20);
            this.txtSecondGame2.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 36;
            this.label7.Text = "Game 2";
            // 
            // txtSecondGame1
            // 
            this.txtSecondGame1.BackColor = System.Drawing.SystemColors.Control;
            this.txtSecondGame1.Location = new System.Drawing.Point(80, 47);
            this.txtSecondGame1.Name = "txtSecondGame1";
            this.txtSecondGame1.Size = new System.Drawing.Size(100, 20);
            this.txtSecondGame1.TabIndex = 35;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 34;
            this.label8.Text = "Game 1";
            // 
            // txtSecond
            // 
            this.txtSecond.BackColor = System.Drawing.SystemColors.Control;
            this.txtSecond.Location = new System.Drawing.Point(80, 21);
            this.txtSecond.Name = "txtSecond";
            this.txtSecond.Size = new System.Drawing.Size(100, 20);
            this.txtSecond.TabIndex = 33;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 32;
            this.label9.Text = "Name";
            // 
            // txtThirdGame3
            // 
            this.txtThirdGame3.BackColor = System.Drawing.SystemColors.Control;
            this.txtThirdGame3.Location = new System.Drawing.Point(620, 191);
            this.txtThirdGame3.Name = "txtThirdGame3";
            this.txtThirdGame3.Size = new System.Drawing.Size(100, 20);
            this.txtThirdGame3.TabIndex = 106;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(559, 194);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 13);
            this.label14.TabIndex = 105;
            this.label14.Text = "Game 3";
            // 
            // txtThirdGame2
            // 
            this.txtThirdGame2.BackColor = System.Drawing.SystemColors.Control;
            this.txtThirdGame2.Location = new System.Drawing.Point(620, 165);
            this.txtThirdGame2.Name = "txtThirdGame2";
            this.txtThirdGame2.Size = new System.Drawing.Size(100, 20);
            this.txtThirdGame2.TabIndex = 104;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(559, 168);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 13);
            this.label15.TabIndex = 103;
            this.label15.Text = "Game 2";
            // 
            // txtThirdGame1
            // 
            this.txtThirdGame1.BackColor = System.Drawing.SystemColors.Control;
            this.txtThirdGame1.Location = new System.Drawing.Point(620, 139);
            this.txtThirdGame1.Name = "txtThirdGame1";
            this.txtThirdGame1.Size = new System.Drawing.Size(100, 20);
            this.txtThirdGame1.TabIndex = 102;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(559, 142);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 13);
            this.label16.TabIndex = 101;
            this.label16.Text = "Game 1";
            // 
            // txtThird
            // 
            this.txtThird.BackColor = System.Drawing.SystemColors.Control;
            this.txtThird.Location = new System.Drawing.Point(620, 113);
            this.txtThird.Name = "txtThird";
            this.txtThird.Size = new System.Drawing.Size(100, 20);
            this.txtThird.TabIndex = 100;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(559, 116);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 13);
            this.label17.TabIndex = 99;
            this.label17.Text = "Name";
            // 
            // groupBox4
            // 
            this.groupBox4.Location = new System.Drawing.Point(540, 92);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(210, 141);
            this.groupBox4.TabIndex = 107;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "3rd Place";
            // 
            // txtFirstGame3
            // 
            this.txtFirstGame3.BackColor = System.Drawing.SystemColors.Control;
            this.txtFirstGame3.Location = new System.Drawing.Point(156, 191);
            this.txtFirstGame3.Name = "txtFirstGame3";
            this.txtFirstGame3.Size = new System.Drawing.Size(100, 20);
            this.txtFirstGame3.TabIndex = 97;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(95, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 96;
            this.label4.Text = "Game 3";
            // 
            // txtFirstGame2
            // 
            this.txtFirstGame2.BackColor = System.Drawing.SystemColors.Control;
            this.txtFirstGame2.Location = new System.Drawing.Point(156, 165);
            this.txtFirstGame2.Name = "txtFirstGame2";
            this.txtFirstGame2.Size = new System.Drawing.Size(100, 20);
            this.txtFirstGame2.TabIndex = 95;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(95, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 94;
            this.label3.Text = "Game 2";
            // 
            // txtFirstGame1
            // 
            this.txtFirstGame1.BackColor = System.Drawing.SystemColors.Control;
            this.txtFirstGame1.Location = new System.Drawing.Point(156, 139);
            this.txtFirstGame1.Name = "txtFirstGame1";
            this.txtFirstGame1.Size = new System.Drawing.Size(100, 20);
            this.txtFirstGame1.TabIndex = 93;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(95, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 92;
            this.label1.Text = "Game 1";
            // 
            // txtFirst
            // 
            this.txtFirst.BackColor = System.Drawing.SystemColors.Control;
            this.txtFirst.Location = new System.Drawing.Point(156, 113);
            this.txtFirst.Name = "txtFirst";
            this.txtFirst.Size = new System.Drawing.Size(100, 20);
            this.txtFirst.TabIndex = 91;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(95, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 90;
            this.label2.Text = "Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(76, 92);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 141);
            this.groupBox1.TabIndex = 98;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "1st Place";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 311);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.txtThirdGame3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtThirdGame2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtThirdGame1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtThird);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.txtFirstGame3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtFirstGame2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFirstGame1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtFirst);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Name = "Form3";
            this.Text = "Final Results";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtSecondGame3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtSecondGame2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSecondGame1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSecond;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtThirdGame3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtThirdGame2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtThirdGame1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtThird;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtFirstGame3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFirstGame2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFirstGame1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFirst;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}