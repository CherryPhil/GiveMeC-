﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pract9
{
    public partial class Form1 : Form
    {
        public static string userInput { get; set; }
        // Bowler #1
        public static string bowler1 { get; set; }
        public static int [] bowler1Scores { get; set; }
        // Bowler #2
        public static string bowler2 { get; set; }
        public static int [] bowler2Scores { get; set; }
        // Bowler #3
        public static string bowler3 { get; set; }
        public static int [] bowler3Scores { get; set; }
        // Bowler #4
        public static string bowler4 { get; set; }
        public static int [] bowler4Scores { get; set; }
        // Bowler #5
        public static string bowler5 { get; set; }
        public static int [] bowler5Scores { get; set; }
        // Bowler #6
        public static string bowler6 { get; set; }
        public static int [] bowler6Scores { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 newform = new Form2();
            newform.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 newForm = new Form3();
            newForm.ShowDialog();
        }

        private void openForm2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Bowler #1
            bowler1 = txtBowler1.Text;
            bowler1Scores = new int[] { int.Parse(txtBowler1Game1.Text), int.Parse(txtBowler1Game2.Text), int.Parse(txtBowler1Game3.Text) };

            // Bowler #2
            bowler2 = txtBowler2.Text;
            bowler2Scores = new int[] { int.Parse(txtBowler2Game1.Text), int.Parse(txtBowler2Game2.Text), int.Parse(txtBowler2Game3.Text) };

            // Bowler #3
            bowler3 = txtBowler3.Text;
            bowler3Scores = new int[] { int.Parse(txtBowler3Game1.Text), int.Parse(txtBowler3Game2.Text), int.Parse(txtBowler3Game3.Text) };

            // Bowler #4
            bowler4 = txtBowler4.Text;
            bowler4Scores = new int[] { int.Parse(txtBowler4Game1.Text), int.Parse(txtBowler4Game2.Text), int.Parse(txtBowler4Game3.Text) };

            // Bowler #5
            bowler5 = txtBowler5.Text;
            bowler5Scores = new int[] { int.Parse(txtBowler5Game1.Text), int.Parse(txtBowler5Game2.Text), int.Parse(txtBowler5Game3.Text) };

            // Bowler #6
            bowler6 = txtBowler6.Text;
            bowler6Scores = new int[] { int.Parse(txtBowler6Game1.Text), int.Parse(txtBowler6Game2.Text), int.Parse(txtBowler6Game3.Text) };
            Form2 newForm = new Form2();
            newForm.ShowDialog();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void openForm3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 newForm = new Form3();
            newForm.Show();
        }

        private void textBox23_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 newForm = new Form2();
            newForm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 newForm = new Form3();
            newForm.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBoxInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
