﻿namespace Pract9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openForm2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openForm3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtBowler1Game3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBowler1Game2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBowler1Game1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBowler1 = new System.Windows.Forms.TextBox();
            this.labelDisplay = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtBowler6Game3 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtBowler6Game2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBowler6Game1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtBowler6 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtBowler3Game3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtBowler3Game2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtBowler3Game1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtBowler3 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtBowler5Game3 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtBowler5Game2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtBowler5Game1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtBowler5 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtBowler2Game3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBowler2Game2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBowler2Game1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBowler2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtBowler4Game3 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtBowler4Game2 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtBowler4Game1 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtBowler4 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(785, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openForm2ToolStripMenuItem,
            this.openForm3ToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // openForm2ToolStripMenuItem
            // 
            this.openForm2ToolStripMenuItem.Name = "openForm2ToolStripMenuItem";
            this.openForm2ToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.openForm2ToolStripMenuItem.Text = "Open Form 2";
            this.openForm2ToolStripMenuItem.Click += new System.EventHandler(this.openForm2ToolStripMenuItem_Click);
            // 
            // openForm3ToolStripMenuItem
            // 
            this.openForm3ToolStripMenuItem.Name = "openForm3ToolStripMenuItem";
            this.openForm3ToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.openForm3ToolStripMenuItem.Text = "Open Form 3";
            this.openForm3ToolStripMenuItem.Click += new System.EventHandler(this.openForm3ToolStripMenuItem_Click);
            // 
            // txtBowler1Game3
            // 
            this.txtBowler1Game3.Location = new System.Drawing.Point(137, 187);
            this.txtBowler1Game3.Name = "txtBowler1Game3";
            this.txtBowler1Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler1Game3.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(76, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "Game 3";
            // 
            // txtBowler1Game2
            // 
            this.txtBowler1Game2.Location = new System.Drawing.Point(137, 161);
            this.txtBowler1Game2.Name = "txtBowler1Game2";
            this.txtBowler1Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler1Game2.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 27;
            this.label3.Text = "Game 2";
            // 
            // txtBowler1Game1
            // 
            this.txtBowler1Game1.Location = new System.Drawing.Point(137, 135);
            this.txtBowler1Game1.Name = "txtBowler1Game1";
            this.txtBowler1Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler1Game1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "Game 1";
            // 
            // txtBowler1
            // 
            this.txtBowler1.Location = new System.Drawing.Point(137, 109);
            this.txtBowler1.Name = "txtBowler1";
            this.txtBowler1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler1.TabIndex = 1;
            // 
            // labelDisplay
            // 
            this.labelDisplay.AutoSize = true;
            this.labelDisplay.Location = new System.Drawing.Point(76, 112);
            this.labelDisplay.Name = "labelDisplay";
            this.labelDisplay.Size = new System.Drawing.Size(35, 13);
            this.labelDisplay.TabIndex = 23;
            this.labelDisplay.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(283, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(185, 24);
            this.label5.TabIndex = 22;
            this.label5.Text = "Bowling Tournament";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(57, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 141);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bowler #1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtBowler6Game3);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtBowler6Game2);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtBowler6Game1);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtBowler6);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Location = new System.Drawing.Point(521, 244);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(210, 141);
            this.groupBox2.TabIndex = 36;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bowler #6";
            // 
            // txtBowler6Game3
            // 
            this.txtBowler6Game3.Location = new System.Drawing.Point(80, 99);
            this.txtBowler6Game3.Name = "txtBowler6Game3";
            this.txtBowler6Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler6Game3.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 38;
            this.label10.Text = "Game 3";
            // 
            // txtBowler6Game2
            // 
            this.txtBowler6Game2.Location = new System.Drawing.Point(80, 73);
            this.txtBowler6Game2.Name = "txtBowler6Game2";
            this.txtBowler6Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler6Game2.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 36;
            this.label11.Text = "Game 2";
            // 
            // txtBowler6Game1
            // 
            this.txtBowler6Game1.Location = new System.Drawing.Point(80, 47);
            this.txtBowler6Game1.Name = "txtBowler6Game1";
            this.txtBowler6Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler6Game1.TabIndex = 22;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 13);
            this.label12.TabIndex = 34;
            this.label12.Text = "Game 1";
            // 
            // txtBowler6
            // 
            this.txtBowler6.Location = new System.Drawing.Point(80, 21);
            this.txtBowler6.Name = "txtBowler6";
            this.txtBowler6.Size = new System.Drawing.Size(100, 20);
            this.txtBowler6.TabIndex = 21;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 13);
            this.label13.TabIndex = 32;
            this.label13.Text = "Name";
            // 
            // txtBowler3Game3
            // 
            this.txtBowler3Game3.Location = new System.Drawing.Point(601, 187);
            this.txtBowler3Game3.Name = "txtBowler3Game3";
            this.txtBowler3Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler3Game3.TabIndex = 12;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(540, 190);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 13);
            this.label14.TabIndex = 47;
            this.label14.Text = "Game 3";
            // 
            // txtBowler3Game2
            // 
            this.txtBowler3Game2.Location = new System.Drawing.Point(601, 161);
            this.txtBowler3Game2.Name = "txtBowler3Game2";
            this.txtBowler3Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler3Game2.TabIndex = 11;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(540, 164);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 13);
            this.label15.TabIndex = 45;
            this.label15.Text = "Game 2";
            // 
            // txtBowler3Game1
            // 
            this.txtBowler3Game1.Location = new System.Drawing.Point(601, 135);
            this.txtBowler3Game1.Name = "txtBowler3Game1";
            this.txtBowler3Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler3Game1.TabIndex = 10;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(540, 138);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 13);
            this.label16.TabIndex = 43;
            this.label16.Text = "Game 1";
            // 
            // txtBowler3
            // 
            this.txtBowler3.Location = new System.Drawing.Point(601, 109);
            this.txtBowler3.Name = "txtBowler3";
            this.txtBowler3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler3.TabIndex = 9;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(540, 112);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 13);
            this.label17.TabIndex = 41;
            this.label17.Text = "Name";
            // 
            // groupBox4
            // 
            this.groupBox4.Location = new System.Drawing.Point(521, 88);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(210, 141);
            this.groupBox4.TabIndex = 33;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Bowler #3";
            // 
            // txtBowler5Game3
            // 
            this.txtBowler5Game3.Location = new System.Drawing.Point(368, 343);
            this.txtBowler5Game3.Name = "txtBowler5Game3";
            this.txtBowler5Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler5Game3.TabIndex = 20;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(307, 346);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(44, 13);
            this.label18.TabIndex = 56;
            this.label18.Text = "Game 3";
            // 
            // txtBowler5Game2
            // 
            this.txtBowler5Game2.Location = new System.Drawing.Point(368, 317);
            this.txtBowler5Game2.Name = "txtBowler5Game2";
            this.txtBowler5Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler5Game2.TabIndex = 19;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(307, 320);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 13);
            this.label19.TabIndex = 54;
            this.label19.Text = "Game 2";
            // 
            // txtBowler5Game1
            // 
            this.txtBowler5Game1.Location = new System.Drawing.Point(368, 291);
            this.txtBowler5Game1.Name = "txtBowler5Game1";
            this.txtBowler5Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler5Game1.TabIndex = 18;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(307, 294);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(44, 13);
            this.label20.TabIndex = 52;
            this.label20.Text = "Game 1";
            // 
            // txtBowler5
            // 
            this.txtBowler5.Location = new System.Drawing.Point(368, 265);
            this.txtBowler5.Name = "txtBowler5";
            this.txtBowler5.Size = new System.Drawing.Size(100, 20);
            this.txtBowler5.TabIndex = 17;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(307, 268);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 13);
            this.label21.TabIndex = 50;
            this.label21.Text = "Name";
            // 
            // groupBox5
            // 
            this.groupBox5.Location = new System.Drawing.Point(288, 244);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(210, 141);
            this.groupBox5.TabIndex = 35;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Bowler #5";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtBowler2Game3);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtBowler2Game2);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txtBowler2Game1);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txtBowler2);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Location = new System.Drawing.Point(288, 88);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(210, 141);
            this.groupBox3.TabIndex = 32;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Bowler #2";
            // 
            // txtBowler2Game3
            // 
            this.txtBowler2Game3.Location = new System.Drawing.Point(80, 99);
            this.txtBowler2Game3.Name = "txtBowler2Game3";
            this.txtBowler2Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler2Game3.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 102);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "Game 3";
            // 
            // txtBowler2Game2
            // 
            this.txtBowler2Game2.Location = new System.Drawing.Point(80, 73);
            this.txtBowler2Game2.Name = "txtBowler2Game2";
            this.txtBowler2Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler2Game2.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 36;
            this.label7.Text = "Game 2";
            // 
            // txtBowler2Game1
            // 
            this.txtBowler2Game1.Location = new System.Drawing.Point(80, 47);
            this.txtBowler2Game1.Name = "txtBowler2Game1";
            this.txtBowler2Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler2Game1.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 34;
            this.label8.Text = "Game 1";
            // 
            // txtBowler2
            // 
            this.txtBowler2.Location = new System.Drawing.Point(80, 21);
            this.txtBowler2.Name = "txtBowler2";
            this.txtBowler2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler2.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 32;
            this.label9.Text = "Name";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtBowler4Game3);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.txtBowler4Game2);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.txtBowler4Game1);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.txtBowler4);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Location = new System.Drawing.Point(57, 244);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(210, 141);
            this.groupBox6.TabIndex = 34;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Bowler #4";
            // 
            // txtBowler4Game3
            // 
            this.txtBowler4Game3.Location = new System.Drawing.Point(80, 99);
            this.txtBowler4Game3.Name = "txtBowler4Game3";
            this.txtBowler4Game3.Size = new System.Drawing.Size(100, 20);
            this.txtBowler4Game3.TabIndex = 16;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(19, 102);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(44, 13);
            this.label22.TabIndex = 38;
            this.label22.Text = "Game 3";
            // 
            // txtBowler4Game2
            // 
            this.txtBowler4Game2.Location = new System.Drawing.Point(80, 73);
            this.txtBowler4Game2.Name = "txtBowler4Game2";
            this.txtBowler4Game2.Size = new System.Drawing.Size(100, 20);
            this.txtBowler4Game2.TabIndex = 15;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(19, 76);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 13);
            this.label23.TabIndex = 36;
            this.label23.Text = "Game 2";
            // 
            // txtBowler4Game1
            // 
            this.txtBowler4Game1.Location = new System.Drawing.Point(80, 47);
            this.txtBowler4Game1.Name = "txtBowler4Game1";
            this.txtBowler4Game1.Size = new System.Drawing.Size(100, 20);
            this.txtBowler4Game1.TabIndex = 14;
            this.txtBowler4Game1.TextChanged += new System.EventHandler(this.textBox23_TextChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(19, 50);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(44, 13);
            this.label24.TabIndex = 34;
            this.label24.Text = "Game 1";
            // 
            // txtBowler4
            // 
            this.txtBowler4.Location = new System.Drawing.Point(80, 21);
            this.txtBowler4.Name = "txtBowler4";
            this.txtBowler4.Size = new System.Drawing.Size(100, 20);
            this.txtBowler4.TabIndex = 13;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(19, 24);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(35, 13);
            this.label25.TabIndex = 32;
            this.label25.Text = "Name";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(402, 405);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(113, 23);
            this.button3.TabIndex = 60;
            this.button3.Text = "Show Scores";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.openForm2ToolStripMenuItem_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(521, 405);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(121, 23);
            this.button4.TabIndex = 61;
            this.button4.Text = "Show Results";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.openForm3ToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(648, 405);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 62;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 488);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.txtBowler5Game3);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtBowler5Game2);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtBowler5Game1);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtBowler5);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.txtBowler3Game3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtBowler3Game2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtBowler3Game1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtBowler3);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txtBowler1Game3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtBowler1Game2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtBowler1Game1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBowler1);
            this.Controls.Add(this.labelDisplay);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Bowling Tournament";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openForm2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openForm3ToolStripMenuItem;
        private System.Windows.Forms.TextBox txtBowler1Game3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBowler1Game2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBowler1Game1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBowler1;
        private System.Windows.Forms.Label labelDisplay;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtBowler6Game3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtBowler6Game2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtBowler6Game1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtBowler6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtBowler3Game3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtBowler3Game2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtBowler3Game1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtBowler3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtBowler5Game3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtBowler5Game2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtBowler5Game1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtBowler5;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtBowler2Game3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtBowler2Game2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBowler2Game1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBowler2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtBowler4Game3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtBowler4Game2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtBowler4Game1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtBowler4;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
    }
}

