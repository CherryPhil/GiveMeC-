﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eadLab2
{
    public partial class EventRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtAdminNo.Text = String.Empty;
            txtName.Text = String.Empty;
            radioBtnMale.Checked = false;
            radioBtnFemale.Checked = false;
            dropDownCourse.SelectedIndex = 0;
            checkListSports.ClearSelection();
            txtContact.Text = String.Empty;
            txtAdminNo.Focus();
            panelResult.Visible = false;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

        }

    }
}